import tensorflow as tf
import numpy as np
from PIL import Image

MODEL_PATH = "model_6_class.h5"
CLASS_NAMES = ["cardboard","glass","metal","paper","plastic","trash"]

model = tf.keras.models.load_model(MODEL_PATH)

def predict_image(img):
    img = img.resize((224,224))
    arr = np.array(img)/255.0
    arr = np.expand_dims(arr,0)
    preds = model.predict(arr)
    top = np.argmax(preds)
    return CLASS_NAMES[top], preds[0][top], preds[0]
