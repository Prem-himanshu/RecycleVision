import streamlit as st
from PIL import Image
import numpy as np
import predict_6
import predict_10
import predict_12

st.set_page_config(page_title="RecycleVision")

st.title("♻️ RecycleVision – Garbage Classification")

model_choice = st.selectbox("Choose Model:", ["6-Class Model","10-Class Model","12-Class Model"])

uploaded = st.file_uploader("Upload image", type=["jpg","jpeg","png"])

if uploaded:
    img = Image.open(uploaded).convert("RGB")
    st.image(img, caption="Uploaded Image")

    if model_choice=="6-Class Model":
        label, conf, preds = predict_6.predict_image(img)
    elif model_choice=="10-Class Model":
        label, conf, preds = predict_10.predict_image(img)
    else:
        label, conf, preds = predict_12.predict_image(img)

    st.success(f"Prediction: {label} ({conf*100:.2f}%)")
