import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import ModelCheckpoint
import matplotlib.pyplot as plt

DATA_DIR = "data/dataset_6_classes"
IMAGE_SIZE = (224, 224)
BATCH_SIZE = 32
EPOCHS = 15

train_gen = ImageDataGenerator(
    rescale=1/255.,
    rotation_range=25,
    width_shift_range=0.2,
    height_shift_range=0.2,
    zoom_range=0.2,
    shear_range=0.1,
    horizontal_flip=True,
    validation_split=0.2
)

train_data = train_gen.flow_from_directory(
    DATA_DIR, target_size=IMAGE_SIZE, batch_size=BATCH_SIZE,
    class_mode="categorical", subset="training"
)

val_data = train_gen.flow_from_directory(
    DATA_DIR, target_size=IMAGE_SIZE, batch_size=BATCH_SIZE,
    class_mode="categorical", subset="validation"
)

NUM_CLASSES = train_data.num_classes

base_model = MobileNetV2(include_top=False, input_shape=(224,224,3), weights='imagenet')
base_model.trainable = False

x = GlobalAveragePooling2D()(base_model.output)
x = Dropout(0.3)(x)
output = Dense(NUM_CLASSES, activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=output)
model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])

checkpoint = ModelCheckpoint("model_6_class.h5", monitor="val_accuracy", save_best_only=True, mode="max")
history = model.fit(train_data, validation_data=val_data, epochs=EPOCHS, callbacks=[checkpoint])

plt.figure(figsize=(8,4)); plt.plot(history.history['accuracy']); plt.plot(history.history['val_accuracy']); plt.savefig("acc6.png")
plt.figure(figsize=(8,4)); plt.plot(history.history['loss']); plt.plot(history.history['val_loss']); plt.savefig("loss6.png")

print("Training completed.")
