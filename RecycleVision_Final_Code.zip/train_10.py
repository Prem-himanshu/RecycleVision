import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import ModelCheckpoint
import matplotlib.pyplot as plt

DATA_DIR = "data/dataset_10_classes"
IMAGE_SIZE = (224,224)
BATCH_SIZE = 32
EPOCHS = 20

train_gen = ImageDataGenerator(
    rescale=1/255., rotation_range=25, width_shift_range=0.2,
    height_shift_range=0.2, zoom_range=0.2, shear_range=0.1,
    horizontal_flip=True, validation_split=0.2
)

train = train_gen.flow_from_directory(DATA_DIR, target_size=IMAGE_SIZE, batch_size=BATCH_SIZE,
    class_mode="categorical", subset="training")
val = train_gen.flow_from_directory(DATA_DIR, target_size=IMAGE_SIZE, batch_size=BATCH_SIZE,
    class_mode="categorical", subset="validation")

NUM_CLASSES = train.num_classes

base = MobileNetV2(include_top=False, input_shape=(224,224,3), weights='imagenet')
base.trainable = False
x = GlobalAveragePooling2D()(base.output)
x = Dropout(0.35)(x)
out = Dense(NUM_CLASSES, activation='softmax')(x)

model = Model(inputs=base.input, outputs=out)
model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])

chk = ModelCheckpoint("model_10_class.h5", monitor="val_accuracy", save_best_only=True, mode="max")
hist = model.fit(train, validation_data=val, epochs=EPOCHS, callbacks=[chk])

plt.figure(figsize=(8,4)); plt.plot(hist.history['accuracy']); plt.plot(hist.history['val_accuracy']); plt.savefig("acc10.png")
plt.figure(figsize=(8,4)); plt.plot(hist.history['loss']); plt.plot(hist.history['val_loss']); plt.savefig("loss10.png")
