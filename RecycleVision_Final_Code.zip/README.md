# RecycleVision – Garbage Classification

A deep learning project using MobileNetV2 to classify waste into 6, 10, and 12 categories.
